


#ifndef ADC_H
#define ADC_H

#include <stdint.h>

// Function Prototypes
uint16_t do_ADC(void);

#endif /* ADC_H */