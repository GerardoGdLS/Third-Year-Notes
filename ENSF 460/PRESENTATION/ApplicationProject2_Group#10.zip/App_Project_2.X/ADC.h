
#ifndef ADC_H
#define ADC_H

#include <stdint.h>

// Function Prototypes
uint16_t readADC(void);

#endif /* ADC_H */
