
#ifndef TIMEDELAY_H
#define TIMEDELAY_H

// Function prototype for TimeDelay.c
void delay_ms(uint16_t time_ms);

#endif /* TIMEDELAY_H */
