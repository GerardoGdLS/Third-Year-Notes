
#ifndef CLKCHANGE_H
#define	CLKCHANGE_H

#include <xc.h>

void newClk(unsigned int clkval);

#endif	/* CLKCHANGE_H */
