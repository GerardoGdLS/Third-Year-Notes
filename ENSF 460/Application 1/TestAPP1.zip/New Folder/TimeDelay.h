#ifndef TIMEDELAY_H
#define TIMEDELAY_H

#include <stdint.h>

// Function prototype
void delay_ms(uint16_t time_ms);

#endif // TIMEDELAY_H