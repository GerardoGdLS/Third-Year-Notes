// display.h
#ifndef DISPLAY_H
#define DISPLAY_H

#include <stdint.h>

void display(uint16_t ADC_value);
void clearLine(void);

#endif