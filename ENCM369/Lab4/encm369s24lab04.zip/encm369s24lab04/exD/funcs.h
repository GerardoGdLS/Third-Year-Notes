// funcs.h: part of ENCM 369 s24 Lab 4 Exercises D and E

#ifndef FUNCS_H
#define FUNCS_H

int use_pointers(const int *p, int n);

int use_indexes(const int *a, int n);

#endif // #ifndef FUNCS_H
