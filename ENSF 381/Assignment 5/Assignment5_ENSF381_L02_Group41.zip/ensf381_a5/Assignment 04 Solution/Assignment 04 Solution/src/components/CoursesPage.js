import React, { useState, useEffect } from 'react';
import Header from './Header';
import Footer from './Footer';
import CourseItem from './CourseItem';
import EnrollmentList from './EnrollmentList';

const CoursesPage = () => {
  const [studentId, setStudentId] = useState(null);
  const [availableCourses, setAvailableCourses] = useState([]);
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [error, setError] = useState(null);

  const fetchEnrolledCourses = async () => {
    const res = await fetch('http://localhost:5000/students');
    const data = await res.json();
    const student = data.find(s => s.id === studentId);
  
    if (student) {
      setEnrolledCourses(student.enrolled_courses);
    }
  };
  
  useEffect(() => {
    fetchEnrolledCourses();
  }, []);
  
  useEffect(() => {
    const id = localStorage.getItem('studentId');
    if (id) {
      setStudentId(id);
    } else {
      console.warn("No studentId found in localStorage");
    }
  }, []);

  useEffect(() => {
    fetch('http://localhost:5000/courses')
      .then(res => res.json())
      .then(data => setAvailableCourses(data))
      .catch(err => {
        console.error('Failed to fetch courses:', err);
      });
  }, []);

  const handleEnroll = async (course) => {
    const studentId = localStorage.getItem('studentId');
  
    if (!studentId || studentId === 'undefined') {
      console.error('Student ID is invalid or undefined');
      return;
    }
  
    console.log('Making enroll request with student ID:', studentId);
  
    try {
      const response = await fetch(`http://localhost:5000/enroll/${studentId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ course: course })
      });
  
      console.log('Response status:', response.status);
  
      if (response.ok) {
        const data = await response.json();
        console.log('Enrollment response:', data.message);
      } else {
        const errorData = await response.json();
        console.error('Enrollment failed:', errorData.error || 'Unknown error');
      }
    } catch (err) {
      console.error('Enrollment failed with error:', err);
    }
  };
  
  const handleRemove = async (enrollmentId) => {
    const courseToRemove = enrolledCourses.find(c => c.enrollmentId === enrollmentId);
    if (!courseToRemove) return;
  
    try {
      const studentId = localStorage.getItem('studentId');
      if (!studentId) {
        setError('Student ID not found.');
        return;
      }
  
      const response = await fetch(`http://localhost:5000/drop/${studentId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ course: courseToRemove.name }) // or courseToRemove.id
      });
  
      if (response.ok) {
        setEnrolledCourses(prev =>
          prev.filter(course => course.enrollmentId !== enrollmentId)
        );
      } else {
        setError('Failed to remove course.');
      }
    } catch (err) {
      setError('Network error during removal.');
      console.error(err);
    }
  };
  

  useEffect(() => {
    if (!studentId) return;

    fetch(`http://localhost:5000/student_courses/${studentId}`)
      .then(res => res.json())
      .then(data => setEnrolledCourses(data))
      .catch(err => {
        console.error('Failed to fetch student enrolled courses:', err);
        setEnrolledCourses([]); 
      });
  }, [studentId]);

  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      flexDirection: 'column' 
    }}>
      <Header />
      
      <div style={{ 
        flex: 1,
        display: 'flex',
        padding: '20px',
        gap: '30px'
      }}>
        <div style={{ flex: 3 }}>
          <h2 style={{ color: '#004080' }}>Available Courses</h2>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
            gap: '20px'
          }}>
            {availableCourses.map(course => (
              <CourseItem 
                key={course.id} 
                course={course} 
                onEnroll={handleEnroll}
              />
            ))}
          </div>
        </div>
        
        <EnrollmentList 
          enrolledCourses={enrolledCourses}
          onRemove={handleRemove}
        />
      </div>

      <Footer />
    </div>
  );
};

export default CoursesPage;
