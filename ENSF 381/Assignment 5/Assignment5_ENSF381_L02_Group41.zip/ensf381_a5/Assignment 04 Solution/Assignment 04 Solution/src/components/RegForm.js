import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const RegForm = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmpassword, setConfirmPassword] = useState('');
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');
    const [isHovered, setIsHovered] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const { login } = useAuth();
    const navigate = useNavigate();

    const validateForm = () => {
        if (!/^[A-Za-z][A-Za-z0-9_-]{2,19}$/.test(username)) {
          setError('Username must start with a letter, be 3-20 characters long, and contain only letters, numbers, hyphens, or underscores.');
          return false;
        }
      
        if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()\-_+=\[\]{}|;:'",.<>?/`~]).{8,}$/.test(password)) {
          setError('Password must be at least 8 characters long, include one uppercase letter, one lowercase letter, one number, and one special character.');
          return false;
        }
      
        if (password !== confirmpassword) {
          setError('Passwords do not match.');
          return false;
        }
      
        if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(email)) {
          setError('Please enter a valid email address.');
          return false;
        }
      
        setError('');
        return true;
      };      

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);
      
        if (!validateForm()) {
          setIsLoading(false);
          return;
        }
      
        try {
          const response = await fetch('http://localhost:5000/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              username,
              password,
              email
            })
          });
      
          const data = await response.json();
      
          if (response.ok) {
            navigate('/login');
          } else {
            setError(data.message || 'Signup failed.');
          }
      
        } catch (err) {
          setError('Network error. Please try again.');
        } finally {
          setIsLoading(false);
        }
    };
      
    return(
        <>
        <h1 style={{ textAlign: 'center', color:'#004080' }}>Sign Up</h1>
        <form onSubmit={handleSubmit} style={{ 
            display: 'flex',
            flexDirection: 'column',
            backgroundColor: '#d4d4d4',
            textAlign: 'center',
            alignItems: 'center',
            padding: '30px',
            marginLeft: '150px',
            marginRight: '150px',
            borderRadius: '30px',
            boxShadow: '5px 5px 10px grey'
          }}>
            <div style={{ marginBottom: '15px' }}>
                <label htmlFor="username" style={{ display: 'block', marginBottom: '5px' }}>
                Username:
                </label>
                <input
                type="text"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                style={{ width: '100%', padding: '8px' }}
                />
            </div>

            <div style={{ marginBottom: '20px' }}>
                <label htmlFor="password" style={{ display: 'block', marginBottom: '5px' }}>
                Password:
                </label>
                <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                style={{ width: '100%', padding: '8px' }}
                />
            </div>

            <div style={{marginBottom: '15px'}}>
                <label htmlFor="confirmpassword" style={{ display: 'block', marginBottom: '5px'}}>
                    Confirm Password:
                </label>
                <input
                type="confirmpassword"
                id="confirmpassword"
                value={confirmpassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                style={{ width: '100%', padding: '8px'}}
                />
            </div>

            <div style={{marginBottom: '15px'}}>
                <label htmlFor="email" style={{ display: 'block', marginBottom: '5px'}}>
                    Email:
                </label>
                <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                style={{ width: '100%', padding: '8px'}}
                />
            </div>

            {error && (
                <div style={{ 
                color: '#D32F2F', 
                backgroundColor: '#FFEBEE', 
                padding: '10px', 
                borderRadius: '4px',
                marginBottom: '15px'
                }}>
                {error}
                </div>
            )}

            <button 
                type="submit" 
                disabled={isLoading}
                style={{
                padding: '10px',
                backgroundColor: '#4CAF50',
                color: 'white',
                borderRadius: '5px',
                margin: '10px',
                opacity: isHovered ? '1.0' : '0.5',
                }}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
            >
                {isLoading ? 'Creating Profile...' : 'Signup'}
            </button>
        </form>
        </>
    )
}

export default RegForm;