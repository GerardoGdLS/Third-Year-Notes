#Gerardo Garcia de Leon UCID 30172099
#Kiersten Konig UCID 30171448

from flask import Flask, jsonify, request
from flask_cors import CORS
import json
import random

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return "Flask Backend is running!"

students = []
next_id = 1 #We use a global variable for tracking the id

#ENDPOINT 1
@app.route('/register', methods=['POST'])
def register():
    global next_id

    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')

    # Check if any required field is missing
    if not all([username, password, email]):
        return jsonify({"success": False, "message": "All fields are required."}), 400

    # Verify username doesn't exist already
    for student in students:
        if student['username'] == username:
            return jsonify({"success": False, "message": "Username already taken."}), 409

    # After checking evrything is valid we can register the student
    new_student = {
        "id": next_id,
        "username": username,
        "password": password,
        "email": email,
        "enrolled_courses": []
    }

    students.append(new_student)
    next_id += 1

    return jsonify({"success": True, "message": "Registration successful."}), 201

#ENDPOINT 2
@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({"success": False, "message": "Username and password are required."}), 400

    for student in students:
        if student['username'] == username and student['password'] == password:
            return jsonify({"success": True, "message": "Login successful.", "student": student}), 200

    return jsonify({"success": False, "message": "Invalid username or password."}), 401

#ENDPOINT 3
@app.route('/testimonials', methods=['GET'])
def get_testimonials():
    try:
        with open('testimonials.json', 'r') as file:
            testimonials = json.load(file)
        random_testimonials = random.sample(testimonials, 2)
        return jsonify(random_testimonials), 200
    except Exception as e:
        return jsonify({"error": "Failed to load testimonials", "details": str(e)}), 500
    
# Endpoint 4
@app.route('/enroll/<student_id>', methods=['POST'])
def enroll_course(student_id):
    student_id = int(student_id)

    data = request.get_json()
    course = data.get('course')

    # Searching the student by their ID
    student = next((s for s in students if s['id'] == student_id), None)

    if not student:
        return jsonify({'error': 'Student not found'}), 404

    if not course:
        return jsonify({'error': 'No course information provided'}), 400

    # Check if the course is already in the student's enrolled courses
    if any(c['id'] == course['id'] for c in student['enrolled_courses']):
        return jsonify({'message': 'Already enrolled in this course'}), 200

    # Add the course
    student['enrolled_courses'].append(course)

    return jsonify({'message': f"Successfully enrolled in {course['name']}"}), 200

#ENDPOINT 5
@app.route('/drop/<student_id>', methods=['DELETE'])
def drop_course(student_id):
    print(f"Received student_id: {student_id}")  # Tried printinng this to debug but was not printing
    student_id = int(student_id)
    
    data = request.get_json()
    course = data.get('course')

    # Searching the student by their ID
    student = next((s for s in students if s['id'] == student_id), None)

    if not student:
        return jsonify({'error': 'Student not found'}), 404

    if not course:
        return jsonify({'error': 'No course information provided'}), 400

    if course not in student['enrolled_courses']:
        return jsonify({'error': 'Course not found in enrolled courses'}), 404

    # Remove course from enrolled_courses
    student['enrolled_courses'].remove(course)

    return jsonify({'message': f'Successfully dropped {course}'}), 200


#ENDPOINT 6
@app.route('/courses', methods=['GET'])
def get_courses():
    try:
        with open('courses.json') as f:
            courses = json.load(f)
        return jsonify(courses), 200
    except Exception as e:
        return jsonify({'error': 'Failed to load courses'}), 500
    
#ENDPOINT 7
@app.route('/student_courses/<student_id>', methods=['GET'])
def get_student_courses(student_id):
    for student in students:
        if student["id"] == student_id:
            return jsonify(student.get("enrolled_courses", [])), 200
    return jsonify([]), 200

if __name__ == '__main__':
    app.run()