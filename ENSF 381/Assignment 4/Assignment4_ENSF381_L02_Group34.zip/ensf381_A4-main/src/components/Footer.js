import React from 'react';

function Footer() {
    return (
        <footer>
            <p>© 2025 LMS. All rights reserved.</p>
        </footer>
    );
}

export default Footer;
