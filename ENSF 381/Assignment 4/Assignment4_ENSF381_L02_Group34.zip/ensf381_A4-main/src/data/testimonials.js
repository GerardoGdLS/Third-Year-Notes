const testimonials = [
    {
    studentName: "Alice Johnson",
    courseName: "Web Development",
    review: "Excellent course structure!",
    rating: 5
    },
    // Add 3 more testimonials...
    {
        studentName: "Michael Smith",
        courseName: "Data Science",
        review: "Very informative and well-paced.",
        rating: 4
    },
    {
        studentName: "Sophia Lee",
        courseName: "Cybersecurity Fundamentals",
        review: "Great hands-on exercises and real-world examples.",
        rating: 5
    },
    {
        studentName: "David Brown",
        courseName: "Game Development",
        review: "Loved the Unity tutorials! Highly recommended.",
        rating: 5
    }    
];
export default testimonials;