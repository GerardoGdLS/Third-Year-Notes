/*
File name: Observer.java
Lab 5 Exercise C
Oct 26th 2024
By: Gerardo Garcia de Leon
*/

import java.util.ArrayList;

interface Observer{
	void update(ArrayList<Double> list);
}
