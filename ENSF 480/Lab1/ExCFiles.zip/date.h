/* File name: date.h
   Assignment: Lab 1 Exercise C
   Lab Section: B02
   Completed by: Gerardo Garcia de Leon
   Development Date: Sep 11th, 2024
*/

//date.h
#ifndef DATE_H
#define DATE_H

#include <string>
using namespace std;

class Date {
private:
    string day;
    string month;
    string year;
public:
    ...
};

#endif