/*
 * File name: Component.java
 * Lab 6 Exercise A
 * Nov 1st 2024
 * By: Gerardo Garcia de Leon
 */

import java.awt.Graphics;

interface Component {
	public void draw(Graphics g);
}
